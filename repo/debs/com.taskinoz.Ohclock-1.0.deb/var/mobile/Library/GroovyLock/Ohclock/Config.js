// Configuration Clock
var TwentyFourHour = false; //12 of 24 hour time
var TopColor = "#ffffff";
var BottomColor = "#75637b";
var height = "30%";
