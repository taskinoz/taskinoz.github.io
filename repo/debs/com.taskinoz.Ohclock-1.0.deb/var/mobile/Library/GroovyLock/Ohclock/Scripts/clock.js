function refreshData(){
	var d = new Date();
	var h = d.getHours(); //24 Hour
	var h12 = d.getHours(); //12 Hour
	var m = d.getMinutes();
	//12 Hour Time
	h12 = ( h12 > 12 ) ? h12 - 12 : h12;
	h12 = ( h12 == 0 ) ? 12 : h12;

	var numbers = ["oh","one","two","three","four","five","six","seven","eight","nine","ten",
								"eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty",
								"twenty-one","twenty-two","twenty-three","twenty-four","twenty-five","twenty-six","twenty-seven","twenty-eight","twenty-nine","thirty",
								"thirty-one","thirty-two","thirty-three","thirty-four","thirty-five","thirty-six","thirty-seven","thirty-eight","thirty-nine","forty",
								"forty-one","forty-two","forty-three","forty-four","forty-five","forty-six","forty-seven","forty-eight","forty-nine","fifty",
								"fifty-one","fifty-two","fifty-three","fifty-four","fifty-five","fifty-six","fifty-seven","fifty-eight","fifty-nine","sixty"];

	h = numbers[h];
	h12 = numbers[h12];
	if (m==0) {m = "oclock";}
	else if (m<=9) {m = numbers[0]+numbers[m];}
	else {m = numbers[m];}

	if (TwentyFourHour == true){hour = h;}
	else {hour = h12;}
	//jQuery Output
	$(".container").css('top',height);
	$("#hour").text(hour);
	$("#hour").css('color',TopColor);
	$("#minute").text(m);
	$("#minute").css('color',BottomColor);
}
setInterval(refreshData, 1000);
refreshData();
