function refreshData(){
	//Set the variables for Day, Hours, Minutes, Seconds
	//--------------------------------------------------------
	var d = new Date();
	var h = d.getHours(), h12 = d.getHours();
	var m = d.getMinutes();
	var s = d.getSeconds();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();
	var year = d.getYear() + 1900;
	//--------------------------------------------------------
	//12 Hour Time
	//--------------------------------------------------------
	tod = ( h12 < 12 ) ? "AM" : "PM";
	h12 = ( h12 > 12 ) ? h12 - 12 : h12;
	h12 = ( h12 == 0 ) ? 12 : h12;
	if ( m <= 9){m="0"+m;}
	//--------------------------------------------------------
	//Day and Month arrays, and Language (see config file for languages)
	//--------------------------------------------------------
	switch(Language) {
	    case "en":
			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	        break;
	    case "pg":
			monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
	        break;
			case "ge":
			monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
	        break;
			case "fr":
			monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
					break;
			case "sp":
			monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
	        break;
			case "ru":
			monthA = ["Января","Февраль","Март","Апреля","Май","Июнь","Июль","Август","Сентябрь","Октября","Ноября","Декабрь"];
	        break;
			case "fn":
			monthA = ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"];
	        break;
			case "dn":
			monthA = ["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"];
					break;
			default:
			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	}
	//--------------------------------------------------------
	//Formatting Variables
	date = monthA[month];
	if (compact == true){date = month+1;}
	//--------------------------------------------------------
	//var date = dayA[day]+" "+monthA[month]+" "+daym+" "+year;
	if (TwentyFourHour == true){var hour = h;}
	if (TwentyFourHour == false){var hour = h12;}
	//--------------------------------------------------------
	//jQuery Output
	$("#hours").text(hour);
	$("#minutes").text(m);
	if (compact == true) {
		$("#date").text(month+1); //Stops it from starting at 0
		$("#day").text(daym);
	}
	else{
		$("#hourscompact").text(hour);
		$("#compact").text(date);
		//$("#hours").after("<span>"+monthA[month]+"</span>");
		$("#daycompact").text(daym);
	}
	$("html").css("top", ClockHeight);
	$("body").css("color", color);
	//--------------------------------------------------------
	}
setInterval(refreshData, 1000); //Fix by /u/SOMECoder
refreshData(); // execute function		//End Script
