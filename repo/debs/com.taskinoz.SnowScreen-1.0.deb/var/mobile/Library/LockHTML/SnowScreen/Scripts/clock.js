function refreshData()					//Start Script
	{
	    x = 1;  // x = seconds
	 	var d = new Date();
	 	var h = d.getHours(), hTw = d.getHours();
	 	var m = d.getMinutes();
	 	var s = d.getSeconds();
		
		tod = ( hTw < 12 ) ? "am" : "pm";
		hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
		hTw = ( hTw == 0 ) ? 12 : hTw;
		
		if (h<=9) {h = '0'+h};
		if (m<=9) {m = '0'+m};
		if (s<=9) {s = '0'+s};
		
	 	var	color = '#'+h+m+s;
	 	
	 	if (TwentyFourHour == true){   
	 		var time = h+':'+m;
	 	}
	 	if (TwentyFourHour == false){   
	 		var time = hTw+':'+m+" "+tod;
	 	}
	    
	    if (ShowTime == true){
	    	$("p#time").text(time);
	    }
	     
	    setTimeout(refreshData, x*1000);
	}
	  
	refreshData(); // execute function		//End Script