// Configuration Clock //

var TwentyFourHour = false;
var ShowBattery = true;
var InvertDisplay = false;
var ShowMonth = false;
var FontColor = "ffffff";
var BarColor = "f2f2f2";
var PercentageColor = "ff6464";
var Language = "en";
//Only English [en] and Portuguese [pg] French [fr] Spanish [sp]
