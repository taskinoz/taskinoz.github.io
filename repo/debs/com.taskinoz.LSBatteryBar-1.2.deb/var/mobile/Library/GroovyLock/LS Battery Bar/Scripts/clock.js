//Clock by Taskinoz at Taskinoz.com

function refreshData(){
	var d = new Date();
	var h = d.getHours(), hTw = d.getHours();
	var m = d.getMinutes();
	var s = d.getSeconds();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();

	//12 Hour Time
	tod = ( hTw < 12 ) ? "AM" : "PM";
	hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
	hTw = ( hTw == 0 ) ? 12 : hTw;

	//2 Digit Time and Date
	if (h<=9) {h = '0'+h};
	if (hTw<=9) {hTw = '0'+hTw};
	if (m<=9) {m = '0'+m};
	if (s<=9) {s = '0'+s};
	if (daym<=9) {daym = '0'+daym}

	//Midnight Fix
	if (tod == "AM" && hTw >= 12){hTw = "00"};

	//Weekday and Month arrays and Language
	switch(Language) {
			case "en":
					dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
					break;
			case "pg":
					dayA = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
			monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
					break;
			case "ge":
					dayA = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
			monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
					break;
			case "fr":
					dayA = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
			monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
					break;
			case "sp":
					dayA = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
			monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
					break;
			default:
					dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	}
	day = dayA[day];
	month = monthA[month];

	if (ShowMonth == true){month = ", "+month}
	else(month = "")
	date = day+" "+daym+month;

	//Display Output
	if (TwentyFourHour == true){
		var time = h+':'+m;
	}
	if (TwentyFourHour == false){
		var time = hTw+':'+m;
	}
	$("p#time").text(time);
	$("p#date").text(date);

	//CSS Colours
	$("p").css("color",FontColor);
	if (ShowBattery == true){
		$("#bar").css("background-color",BarColor);
		$("#bar2").css("background-color",PercentageColor);
	}

	//Bar Position
	if (InvertDisplay == true){
		$("p").css("top","0px");
		if (ShowBattery == true){
			$("#bar").css("top","-16px");
			$("#bar2").css("top","-16px");
		}
	}
}
setInterval(refreshData, 1000); //Fix by /u/SOMECoder

refreshData(); // execute function		//End Script
