//Clock by Taskinoz at Taskinoz.com

var ShowTime = true;
var ShowDate = true;

function refreshData()					//Start Script
	{
	    x = 1;  // x = seconds
	 	var d = new Date();
	 	var h = d.getHours(), hTw = d.getHours();
	 	var m = d.getMinutes();
	 	var s = d.getSeconds();
	 	var day = d.getDay();
	 	var month = d.getMonth();
		var daym = d.getDate();

		//12 Hour Time
		tod = ( hTw < 12 ) ? "am" : "pm";
		hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
		hTw = ( hTw == 0 ) ? 12 : hTw;

		if (h<=9) {h = '0'+h};
		if (hTw<=9) {hTw = '0'+hTw};
		if (m<=9) {m = '0'+m};
		if (s<=9) {s = '0'+s};
		if (daym<=9) {daym = '0'+daym}

	 	//Weekday and Month arrays and Language
		switch(Language) {
				case "en":
						dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
						break;
				case "pg":
						dayA = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
				monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
						break;
				case "ge":
						dayA = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
				monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
						break;
				case "fr":
						dayA = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
				monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
						break;
				case "sp":
						dayA = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
				monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
						break;
				default:
						dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
		}
		day = dayA[day];
		month = monthA[month];

	 	//date = day+" "+daym+", "+month;
	 	date = day+" "+daym;

	 	//Display Output

	 	if (TwentyFourHour == true){
	 		var time = h+'.'+m;
	 	}
	 	if (TwentyFourHour == false){
	 		var time = hTw+'.'+m;
	 	}

	    if (ShowTime == true){
	    	$("p#time").text(time);
	    }

     	if (ShowDate == true){
	    	$("p#date").text(date);
	    }
	    if (month == "January" && daym == "1"){
	 		$("p#secret").text("Happy New Year!");
	 	}
	 	$("div.box").css("border-radius",Roundness)
	}
	setInterval(refreshData, 1000); //Fix by /u/SOMECoder

	refreshData(); // execute function		//End Script
