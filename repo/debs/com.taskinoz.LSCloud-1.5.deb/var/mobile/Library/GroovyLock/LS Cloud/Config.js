// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var Roundness = 0;
var Language = "en";
//Only English [en] and Portuguese [pg] French [fr] Spanish [sp]
