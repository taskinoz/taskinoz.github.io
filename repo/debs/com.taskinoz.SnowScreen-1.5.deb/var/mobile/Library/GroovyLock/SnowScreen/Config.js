// Configuration Clock //

var TwentyFourHour = false;			//12 of 24 hour time
var ShowTime = true;						//Show Clock
var ShowDate = true;						//Show Date
var ClockColor = "#ffffff"      //Font Color
var Language = "en";            //Language
var MaxParticles = 25;					//Set the amount of snow particles

//Only English [en], Portuguese [pg], German [ge], French [fr], Spanish [sp], Russian [ru], Finnish [fn], and Danish [dn]
