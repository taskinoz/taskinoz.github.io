// Configuration Clock //

var TwentyFourHour = true;					//12 of 24 hour time
var DayColour = "#f689ed";
var ampm = false;