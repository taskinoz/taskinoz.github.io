//Clock by Taskinoz at Taskinoz.com
$(document).ready(function(){


	//Try Fix This
	//----------------------------------------------------------------------------------------//
	//Split Gradient
	if (Gradient==true){

		//Remove Spaces
		GradientColors = GradientColors.replace(/ /g,"");
		//Created
		GradientColors = GradientColors.split(",");


		var rgb = function (r){
			var arrBuff = new ArrayBuffer(4);
			var vw = new DataView(arrBuff);
			vw.setUint32(0,parseInt(r, 16),false);
			var arrByte = new Uint8Array(arrBuff);

			return "rgba("+arrByte[1]+","+arrByte[2]+","+arrByte[3]+","+GradientOpacity/100+")"; //Add the percentage part of the gradient or flatten array
		}

		function gradient() {
				i=0;
				Backlength = Math.floor(100/(GradientColors.length-1));
				percent = 0;
				while (i!==GradientColors.length){
					GradientColors[i] = GradientColors[i].replace('#','');
					//Convert Hex to RGB
					GradientColors[i] = rgb(GradientColors[i])+" "+percent+"%";
					percent = percent+Backlength;
					i++;
				}
				GradientColors = "linear-gradient(to "+GradientDirection+", "+GradientColors+")";
				GradientColors = GradientColors.toString();
		}
		gradient();
	}
	//----------------------------------------------------------------------------------------//

  //Event listener for tilting the phone
  window.addEventListener('deviceorientation', function(event){
    var x = event.beta,  // -180 to 180
	  y = event.gamma, // -90 to 90
	  z = event.alpha; // 0 to 360

	  $(".tilt").css("transform", "perspective(800px) rotateX("+((-x+InitialTilt/2)+"deg) rotateY("+(y)/2)+"deg)");
  });

  function refreshData(){
	  //--------------------------------------------------------
		//Set the variables for Day, Hours, Minutes, Seconds
		//--------------------------------------------------------
		var d = new Date();
		var h = d.getHours(), h12 = d.getHours();
		var m = d.getMinutes();
		var s = d.getSeconds();
		var day = d.getDay();
		var month = d.getMonth();
		var daym = d.getDate();
		var year = d.getYear() + 1900;

		//--------------------------------------------------------
		//12 Hour Time
		//--------------------------------------------------------

		tod = ( h12 < 12 ) ? "AM" : "PM";
		h12 = ( h12 > 12 ) ? h12 - 12 : h12;
		h12 = ( h12 == 0 ) ? 12 : h12;

		if (h<=9) {h = '0'+h};
		if (h12<=9) {h12 = '0'+h12};

		if (m<=9) {m = '0'+m};
		if (s<=9) {s = '0'+s};

	  //--------------------------------------------------------
	  //Day and Month arrays (condenses a lot of if's) and Language (see config file for languages)
	  //--------------------------------------------------------
	  switch(Language) {
	      case "en":
	          dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	      monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	      date = dayA[day]+" "+monthA[month]+" "+daym+" "+year;
	          break;
	      case "pg":
	          dayA = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
	      monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
	      date = dayA[day]+" "+daym+" "+monthA[month]+" "+year;
	          break;
	      case "ge":
	          dayA = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
	      monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
	      date = dayA[day]+" "+daym+" "+monthA[month]+" "+year;
	          break;
	      case "fr":
	          dayA = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
	      monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
	      date = dayA[day]+" "+daym+" "+monthA[month]+" "+year;
	          break;
	      case "sp":
	          dayA = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
	      monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
	      date = dayA[day]+" "+daym+" "+monthA[month]+" "+year;
	          break;
	      case "ru":
	          dayA = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
	      monthA = ["Января","Февраль","Март","Апреля","Май","Июнь","Июль","Август","Сентябрь","Октября","Ноября","Декабрь"];
	      date = dayA[day]+" "+monthA[month]+" "+daym+" "+year;
	          break;
	      case "fn":
	          dayA = ["Sunnuntai","Maanantai","Tiistai","Keskiviikko","Torstai","Perjantai","Lauantai"];
	      monthA = ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"];
	      date = dayA[day]+" "+monthA[month]+" "+daym+" "+year;
	          break;
	      case "dn":
	          dayA = ["Søndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag"];
	      monthA = ["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"];
	      date = dayA[day]+" "+monthA[month]+" "+daym+" "+year;
	          break;
	      default:
	          dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	      monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	      date = dayA[day]+" "+monthA[month]+" "+daym+" "+year;
	  }

		//--------------------------------------------------------
		//Formatting Variables
		//--------------------------------------------------------

		var day = dayA[day];
	  var date = monthA[month]+" "+daym;

		if (ampm == false){tod = "";}
		if (TwentyFourHour == true){var time = h+':'+m;}
		if (TwentyFourHour == false){var time = h12+':'+m+" "+tod;}

		//--------------------------------------------------------
		//jQuery Output
	  //--------------------------------------------------------

		$("#clock").text(time);
	  if (ShowDay){ $("#day").text(day); }
	  if (ShowDate){ $("#date").text(date); }
		//Background and Gradient Options
		if (Gradient){ $(".tilt").css('background',GradientColors); }
		else { $(".tilt").css('background',background); }

	}

  setInterval(refreshData, 1000);
  refreshData();
})
