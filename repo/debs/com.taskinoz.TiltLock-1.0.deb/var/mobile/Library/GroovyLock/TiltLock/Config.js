// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var ampm = true;
var ShowDay = false;
var ShowDate = false;
var Language = "en";
//var border = "1px solid #000";
var background = "#124";
var InitialTilt = 70;
var Gradient = true;
var GradientColors = "#ffebee, #90caf9, #00bcd4";
var GradientDirection = "right";
var GradientOpacity = 100;
