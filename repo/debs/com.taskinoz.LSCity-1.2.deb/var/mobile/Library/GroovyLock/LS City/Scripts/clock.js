//Clock by Taskinoz at Taskinoz.com
var ShowTime = true;
var ShowDate = true;

function refreshData(){
	 	var d = new Date();
	 	var h = d.getHours(), hTw = d.getHours();
	 	var m = d.getMinutes();
	 	var s = d.getSeconds();
	 	var day = d.getDay();
	 	var month = d.getMonth();
		var daym = d.getDate();

		//12 Hour Time
		tod = ( hTw < 12 ) ? "AM" : "PM";
		hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
		hTw = ( hTw == 0 ) ? 12 : hTw;

		if (h<=9) {h = '0'+h};
		if (hTw<=9) {hTw = '0'+hTw};
		if (m<=9) {m = '0'+m};
		if (s<=9) {s = '0'+s};
		//if (daym<=9) {daym = '0'+daym}

		suffix = ["buffer","first","second","third","fourth","fifth","sixth","seventh","eighth","ninth","tenth","eleventh","twelfth","thirteenth","fourteenth","fifteenth","sixteenth","seventeenth","eighteenth","nineteenth","twentieth","twenty first","twenty second","twenty third","twenty fourth","twenty fifth","twenty sixth","twenty seventh","twenty eighth","twenty ninth","thirtieth","thirty first"];
		suff = suffix[daym];

		switch(Language) {
			case "en":
				dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
			break;
			case "pg":
	    	dayA = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
				monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
	    break;
			case "ge":
	      dayA = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
				monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
	    break;
			case "fr":
				dayA = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
				monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
			break;
			case "sp":
	      dayA = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
				monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
	    break;
			case "ru":
	      dayA = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
				monthA = ["Января","Февраль","Март","Апреля","Май","Июнь","Июль","Август","Сентябрь","Октября","Ноября","Декабрь"];
	    break;
			case "fn":
	      dayA = ["Sunnuntai","Maanantai","Tiistai","Keskiviikko","Torstai","Perjantai","Lauantai"];
				monthA = ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"];
	    break;
			case "dn":
				dayA = ["Søndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag"];
				monthA = ["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"];
			break;
			default:
				dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
		}
		day = dayA[day];
		month = monthA[month];
	 	date = 'the '+suff+' of '+month;

	 	//Display Output
	 	if (TwentyFourHour == true){var time = h+':'+m;}
	 	if (TwentyFourHour == false){var time = hTw+':'+m;}
	  if (ampm == true){var time = time+" "+tod;}

    $("p#time").text(time);
   	$("p#arrow").text("g");
   	$("p#day").text(day);
    $("p#date").text(date);
    $("div#overlap").css("color", DayColour);

    if (month == "January" && daym == "1"){		//Happy New Year (Will Probably Break)
 		$("p#secret").text("Happy New Year!");
	 	}
	}
	setInterval(refreshData, 1000);
	refreshData();
