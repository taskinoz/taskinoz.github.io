//Clock by Taskinoz at Taskinoz.com

function refreshData()					//Start Script
	{
	    x = 1;  // x = seconds
	 	var d = new Date();
	 	var h = d.getHours(), hTw = d.getHours();
	 	var m = d.getMinutes();
	 	var s = d.getSeconds();
	 	var day = d.getDay();
	 	var month = d.getMonth();
		var daym = d.getDate();

		//12 Hour Time
		tod = ( hTw < 12 ) ? "AM" : "PM";
		hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
		hTw = ( hTw == 0 ) ? 12 : hTw;

		if (h<=9) {h = '0'+h};
		//if (hTw<=9) {hTw = '0'+hTw};
		if (m<=9) {m = '0'+m};
		if (s<=9) {s = '0'+s};
		//if (daym<=9) {daym = '0'+daym}

		switch(Language) {
			case "en":
	      dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	    break;
			case "pg":
	      dayA = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
				monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
	    break;
			case "ge":
	      dayA = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
				monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
	    break;
			case "fr":
				dayA = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
				monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
			break;
			case "sp":
	      dayA = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
				monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
	    break;
			case "ru":
	      dayA = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
				monthA = ["Января","Февраль","Март","Апреля","Май","Июнь","Июль","Август","Сентябрь","Октября","Ноября","Декабрь"];
	    break;
			case "fn":
	      dayA = ["Sunnuntai","Maanantai","Tiistai","Keskiviikko","Torstai","Perjantai","Lauantai"];
				monthA = ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"];
	    break;
			case "dn":
				dayA = ["Søndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag"];
				monthA = ["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"];
			break;
			default:
				dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
				monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
		}
		day = dayA[day];
		monthm = monthA[month];

	 	date = day+", "+monthm+" "+daym;

	 	if (ampm == false){
		 	tod = "";
	 	}

	 	//Display Output

	 	if (TwentyFourHour == true){
	 		var time = h+':'+m;
	 	}
	 	if (TwentyFourHour == false){
	 		var time = hTw+':'+m+" "+tod;
	 	}

	    //Display Time
	    $("h1#time").text(time);

	 	//Display Happy New Year
	 	if (month == "0" && daym == "1"){
	 		$("h2#date").text("Happy New Year!");
	 	}
		else {
			//Display Date
	    $("h2#date").text(date);
		}

	 	if (ShowBackground == false){
		 	$("html, body").css("background-color", BackgroundColour);
	 	}

	 	//List Test
	 	if (ShowList == true){
		 	$("div#list").html("<li id=list></li>");
		 	$("h1#TopText").text(TopText);
		 	$("h2#BottomText").text(BottomText);
	 	}


	}
	setInterval(refreshData, 1000);
	refreshData(); // execute function		//End Script
