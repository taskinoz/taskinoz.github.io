// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var ampm = false;
var height = 200;
var Language = "en"; 						//Only English [en] and Portuguese [pg] French [fr] Spanish [sp]
var off = false;

/*If you want this tweak translated or any other tweak, send an email to tristan@taskinoz.com with:

	Days of week:

		Sunday - Translation
		Monday - Translation
		Tuesday - Translation
		Wednesday - Translation
		Thursday - Translation
		Friday - Translation
		Saturday - Translation

	Months of the year:

		January - Translation
		February - Translation
		March - Translation
		April - Translation
		May - Translation
		June - Translation
		July - Translation
		September - Translation
		October - Translation
		November - Translation
		December - Translation

	Language:

		English - Translation

	And if your up to it One to Thirty One [eg]:

		One - Translation
		Two - Translation
*/
