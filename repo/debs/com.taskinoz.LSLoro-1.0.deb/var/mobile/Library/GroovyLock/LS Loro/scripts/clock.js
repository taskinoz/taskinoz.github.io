//Clock by Taskinoz at Taskinoz.com
function refreshData(){
	//Initialise Variables, and get date and time
	var d = new Date();
	var h = d.getHours(), hTw = d.getHours();
	var m = d.getMinutes();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();

	//Create variable arrays
	var numbers = ["zero","one","two","three","four","five","six","seven","eight","nine","ten",
								"eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty",
								"twenty-one","twenty-two","twenty-three","twenty-four","twenty-five","twenty-six","twenty-seven","twenty-eight","twenty-nine","thirty",
								"thirty-one","thirty-two","thirty-three","thirty-four","thirty-five","thirty-six","thirty-seven","thirty-eight","thirty-nine","forty",
								"forty-one","forty-two","forty-three","forty-four","forty-five","forty-six","forty-seven","forty-eight","forty-nine","fifty",
								"fifty-one","fifty-two","fifty-three","fifty-four","fifty-five","fifty-six","fifty-seven","fifty-eight","fifty-nine","sixty"];

	var dayA = ["Sun","Mon","Tue","Wed","Thur","Fri","Sat"];
	var monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];

	//Array to variable
	day = dayA[day];
	month = monthA[month];
	monthD = numbers[daym]

	//Display Output
	$("#day").text(day);
	$("#date").text(monthD);
	$("#month").text(month);

	//Configuration Settings
	$(".container").css("top", Height);
	$(".container").css("color", Color);
}

//Widget refresh rate
setInterval(refreshData, 1000);

refreshData();
