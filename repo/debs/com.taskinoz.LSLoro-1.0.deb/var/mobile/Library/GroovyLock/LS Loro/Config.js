// Configuration Clock //

var Height = 100;
var Color = "#fff";
