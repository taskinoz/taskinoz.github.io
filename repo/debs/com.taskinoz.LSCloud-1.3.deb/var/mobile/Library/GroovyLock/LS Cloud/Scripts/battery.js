//Taken from Cataracs and modified by Taskinoz
//Battery
function refreshData(){					//Start Script	
	$.get("file:///var/mobile/Library/Stats/BatteryStats.txt", function(data){
		var split = data.split("\n");
		var level = split[0].split(": ")[1];
		var state = split[1].split(": ")[1];
		$("p#bar2").css("width",level*0.8);
	});
	}
	setInterval(refreshData, 1000); //Fix by /u/SOMECoder
refreshData();