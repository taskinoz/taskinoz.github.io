var baffled = 0;
function refreshData(){
	var d = new Date();
	var h = d.getHours(), hTw = d.getHours();
	var m = d.getMinutes();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();

	//12 Hour Time
	tod = ( hTw < 12 ) ? "am" : "pm";
	hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
	hTw = ( hTw == 0 ) ? 12 : hTw;

	if (h<=9) {h = '0'+h};
	if (hTw<=9) {hTw = '0'+hTw};
	if (m<=9) {m = '0'+m};
	//if (s<=9) {s = '0'+s};
	if (daym<=9) {daym = '0'+daym}


	var dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	day = dayA[day];
	month = monthA[month];

	//date = day+" "+daym+", "+month;
	date = day+" "+daym;

	//Display Output
	if (TwentyFourHour == true){
		var time = h+'.'+m;
	}
	if (TwentyFourHour == false){
		var time = hTw+'.'+m;
	}

	$(".time").text(time);
	if (ShowDate){$(".date").text(date);}
	if (month == "January" && day == "01"){
		$(".date").text("Happy New Year!");
	}
	$(".time").css("color",TimeColor);
	$(".date").css("color",DateColor);
	if (baffled == 1){
		nowbaffle();
		baffled = 1337;
	}
	else{
		baffled++;
	}
}
setInterval(refreshData, 1000);
refreshData();

function nowbaffle() {
let b = baffle('.time, .date').start();
				b.set({
							speed: 100,
							characters: '▓▒█<>/'
					});
				b.reveal(1000);
}
