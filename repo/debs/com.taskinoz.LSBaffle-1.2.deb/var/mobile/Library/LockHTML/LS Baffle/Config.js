var TwentyFourHour = false;
var ShowDate = true;
var TimeColor = "#fff";
var DateColor = "#fff";
