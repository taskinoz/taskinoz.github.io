// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var ampm = false;
var ClockHeight = 100;