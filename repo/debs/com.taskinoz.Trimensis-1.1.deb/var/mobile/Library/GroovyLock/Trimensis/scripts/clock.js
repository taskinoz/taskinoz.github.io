//Clock by Taskinoz at Taskinoz.com
function refreshData(){
	// Date Variable initialisation
	var d = new Date();
	var h = d.getHours(), h12 = d.getHours();
	var m = d.getMinutes();
	var s = d.getSeconds();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();
	var year = d.getYear() + 1900;

	// 12 Hour Time
	h12 = ( h12 > 12 ) ? h12 - 12 : h12;
	h12 = ( h12 == 0 ) ? 12 : h12;
	// Time Formatting
	if (h<=9) {h = '0'+h};
	if (h12<=9) {h12 = '0'+h12};
	//if (h12<=9) {h12 = '0'+h12};
	if (m<=9) {m = '0'+m};
	if (s<=9) {s = '0'+s};
	// Month Arrays
	switch(Language) {
	    case "en":
			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	        break;
	    case "pg":
			monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
	        break;
			case "ge":
			monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
	        break;
			case "fr":
			monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
					break;
			case "sp":
			monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
	        break;
			default:
			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
	}
	var suffix = ["buffer","st",'nd',"rd","th","th","th","th","th","th","th","th","th","th","th","th","th","th","th","th","th","st","nd","rd","th","th","th","th","th","th","th","st"];

	if (TwentyFourHour == true){var time = h+':'+m;}
	if (TwentyFourHour == false){var time = h12+':'+m;}

	// String manipulation
	var text = monthA[month];
	var monthlen = text.length/3;
	var remainder = text.length%3;
	if (remainder == 0){
		line1 = line2 = line3 = monthlen;
	}
	else {
		var line1 = line3 = Math.floor(monthlen);
		var line2 = monthlen + remainder;
	}
	line1txt = text.substr(0,line1);
	line2txt = text.substr(line1,line2);
	line3txt = text.substr(line1+line2,line2+line3);
	//End string manipulation
	$("html").css("top",ClockHeight);
	$("html").css("color",Color);
	$(".line").css("border-color",Color);
	$("#line1").text(line1txt);
	$("#line2").text(line2txt);
	$("#line3").text(line3txt);
	$("#date").text(daym+suffix[daym]);
	$("#time").text(time);
	}
setInterval(refreshData, 1000);
refreshData();
