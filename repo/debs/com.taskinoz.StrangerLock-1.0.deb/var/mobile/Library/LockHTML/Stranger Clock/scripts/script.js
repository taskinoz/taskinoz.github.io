$(document).ready(function() {
  // Get Title
  var title = $('title').text();

  function refreshData(){
  	//Set the variables for Day, Hours, Minutes, Seconds
  	var d = new Date();
  	var h = d.getHours(), h12 = d.getHours();
  	var m = d.getMinutes();
  	var s = d.getSeconds();
  	var day = d.getDay();
  	var month = d.getMonth();
  	var daym = d.getDate();
  	var year = d.getYear() + 1900;

  	//12 Hour Time
  	tod = ( h12 < 12 ) ? "AM" : "PM";
  	h12 = ( h12 > 12 ) ? h12 - 12 : h12;
  	h12 = ( h12 == 0 ) ? 12 : h12;

  	if (h<=9) {h = '0'+h};
  	if (h12<=9) {h12 = '0'+h12};
  	//if (h12<=9) {h12 = '0'+h12};
  	if (m<=9) {m = '0'+m};
  	if (s<=9) {s = '0'+s};
  	//if (daym<=9) {daym = '0'+daym}

  	//Day and Month arrays (condenses a lot of if's) and Language (see config file for languages)
  	switch(Language) {
  	    case "en":
  	        dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
  			date = monthA[month]+" "+daym;
  	        break;
  	    case "pg":
  	        dayA = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
  			monthA = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
  			date = daym+" "+monthA[month];
  	        break;
  			case "ge":
  	        dayA = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
  			monthA = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
  			date = daym+" "+monthA[month];
  	        break;
  			case "fr":
  					dayA = ["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"];
  			monthA = ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
  			date = daym+" "+monthA[month];
  					break;
  			case "sp":
  	        dayA = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
  			monthA = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
  			date = daym+" "+monthA[month];
  	        break;
  			case "ru":
  	        dayA = ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"];
  			monthA = ["Января","Февраль","Март","Апреля","Май","Июнь","Июль","Август","Сентябрь","Октября","Ноября","Декабрь"];
  			date = daym+" "+monthA[month];
  	        break;
  			case "fn":
  	        dayA = ["Sunnuntai","Maanantai","Tiistai","Keskiviikko","Torstai","Perjantai","Lauantai"];
  			monthA = ["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"];
  			date = daym+" "+monthA[month];
  	        break;
  			case "dn":
  					dayA = ["Søndag","Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag"];
  			monthA = ["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"];
  			date = daym+" "+monthA[month];
  					break;
  			default:
  					dayA = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  			monthA = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"];
  			date = monthA[month]+" "+daym;
  	}

  	//Formatting Variables
  	//var date = monthA[month]+" "+daym;
  	if (TwentyFourHour == true){var time = h+':'+m;}
  	if (TwentyFourHour == false){var time = h12+':'+m;}

  	//jQuery Output
  	// $(".time").text(time);
  	// $(".date").text(date);

    // Strangify
    // Split the text
    x = time.split('');
    y = date.split('');
    // Add spans to the first and last character
    x[0] = '<span class="first">'+x[0]+'</span><span>';x[x.length-1] = '</span><span class="last">'+x[x.length-1]+'</span>';
    y[0] = '<span class="first">'+y[0]+'</span><span>';y[y.length-1] = '</span><span class="last">'+y[y.length-1]+'</span>';
    // Merge array
    x = x.toString();
    y = y.toString();
    // Replace ","
    x = x.replace(/,/g,"");
    y = y.replace(/,/g,"");

    $('title').text(title+" | "+time+" "+date);
    // Strangify
    $('.time').html(x);
    $('.date').html(y);

    // Wallpaper Tint
    if (WallpaperTint){
      $('body').css("background","rgba(0,0,0,0."+TintAmount+")");
    }
  }


  setInterval(refreshData, 1000);
  refreshData();

});
