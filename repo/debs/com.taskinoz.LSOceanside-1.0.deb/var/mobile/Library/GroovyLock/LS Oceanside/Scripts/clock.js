function refreshData(){
	//Set the variables for Day, Hours, Minutes, Seconds
	//--------------------------------------------------------
	var d = new Date();
	var h = d.getHours(), h12 = d.getHours();
	var m = d.getMinutes();
	var s = d.getSeconds();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();
	var year = d.getYear() + 1900;
	//--------------------------------------------------------
	//12 Hour Time
	//--------------------------------------------------------
	tod = ( h12 < 12 ) ? "AM" : "PM";
	h12 = ( h12 > 12 ) ? h12 - 12 : h12;
	h12 = ( h12 == 0 ) ? 12 : h12;
	//--------------------------------------------------------
	//var date = dayA[day]+" "+monthA[month]+" "+daym+" "+year;
	if (TwentyFourHour == true){var hour = h;}
	if (TwentyFourHour == false){var hour = h12;}
	if (m<=9) {m = '0'+m}
	//--------------------------------------------------------
	//Day and hour as text
	dayA = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
	hourA = ["zero","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve"];
	hour = hourA[hour];
	day = dayA[day];
	//--------------------------------------------------------
	//jQuery Output
	$("#hours").text(hour);
	$("#minutes").text(m);
	$("#day").text(day);
	//$("html").css("top", ClockHeight);
	//--------------------------------------------------------
	}
setInterval(refreshData, 1000); //Fix by /u/SOMECoder
refreshData(); // execute function

//Stylesheet check
if (compact == true){$("#switch_style").attr("href","style2.css");}
else {$("#switch_style").attr("href","style.css");}
