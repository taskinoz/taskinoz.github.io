// Docs at http://simpleweatherjs.com
$(document).ready(function() {
  $.simpleWeather({
    //location: 'Austin, TX',
    woeid: woeid,
    unit: unit,
    success: function(weather) {
      degs = weather.temp+'&deg;'+weather.units.temp;
      weth = weather.currently;
  
      $("#temp").html(degs);
      $("#weather").html(weth);
    },
    error: function(error) {
      $("#weather").html('<p>'+error+'</p>');
    }
  });
});
setTimeout(run, 1000);