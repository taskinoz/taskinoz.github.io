// Configuration Clock //

var TwentyFourHour = true;					//12 of 24 hour time
var ZeroAtMidnight = false;
var ampm = true;
var unit = "c";
var woeid = 1105779;
var ClockHeight = 50;
var Language = "en"; 						//Only English [en], Portuguese [pg], German [ge], French [fr], Spanish [sp], Russian [ru], Finnish [fn], and Danish [dn]
var Background = "linear-gradient(to left, rgba(57, 59, 98, 0.7) 0%, rgba(81, 60, 99, 0.7) 13%, rgba(140, 65, 104, 0.7) 28%, rgba(203, 78, 108, 0.7) 41%, rgba(237, 106, 111, 0.7) 55%, rgba(252, 155, 112, 0.7) 68%, rgba(254, 203, 111, 0.7) 80%, rgba(255, 221, 123, 0.7) 90%, rgba(254, 222, 150, 0.7) 100%)";
var TextColour = "#fff";
/*If you want this tweak translated or any other tweak, send an email to tristan@taskinoz.com with:

	Days of week:

		Sunday - Translation
		Monday - Translation
		Tuesday - Translation
		Wednesday - Translation
		Thursday - Translation
		Friday - Translation
		Saturday - Translation

	Months of the year:

		January - Translation
		February - Translation
		March - Translation
		April - Translation
		May - Translation
		June - Translation
		July - Translation
		September - Translation
		October - Translation
		November - Translation
		December - Translation

	Language:

		English - Translation

	And if your up to it One to Thirty One [eg]:

		One - Translation
		Two - Translation
*/
