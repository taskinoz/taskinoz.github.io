// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var Language = "en";
var ClockHeight = 100;
var Color = "#000000";
