// Configuration Clock //

var TwentyFourHour = true;					//12 of 24 hour time