//Clock by Taskinoz at Taskinoz.com

var ShowTime = true;
var ShowDate = true;

function refreshData()					//Start Script
	{
	    x = 1;  // x = seconds
	 	var d = new Date();
	 	var h = d.getHours(), hTw = d.getHours();
	 	var m = d.getMinutes();
	 	var s = d.getSeconds();
	 	var day = d.getDay();
	 	var month = d.getMonth();
		var daym = d.getDate();

		//12 Hour Time
		tod = ( hTw < 12 ) ? "AM" : "PM";
		hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
		hTw = ( hTw == 0 ) ? 12 : hTw;
		
		if (h<=9) {h = '0'+h};
		if (hTw<=9) {hTw = '0'+hTw};
		if (m<=9) {m = '0'+m};
		if (s<=9) {s = '0'+s};
		//if (daym<=9) {daym = '0'+daym}
		
	 	//Numbers to text ---------------- This couldve been done better but this was the easiest way
	 	//TODO - Convert to array v1.1
	 	if (daym == 1){daym = "first"}
	 	if (daym == 2){daym = "second"}
	 	if (daym == 3){daym = "third"}
	 	if (daym == 4){daym = "fourth"}
	 	if (daym == 5){daym = "fifth"}
	 	if (daym == 6){daym = "sixth"}
	 	if (daym == 7){daym = "seventh"}
	 	if (daym == 8){daym = "eighth"}
	 	if (daym == 9){daym = "ninth"}
	 	if (daym == 10){daym = "tenth"}
	 	if (daym == 11){daym = "eleventh"}
	 	if (daym == 12){daym = "twelfth"}
	 	if (daym == 13){daym = "thirteenth"}
	 	if (daym == 14){daym = "fourteenth"}
	 	if (daym == 15){daym = "fifteenth"}
	 	if (daym == 16){daym = "sixteenth"}
	 	if (daym == 17){daym = "seventeenth"}
	 	if (daym == 18){daym = "eighteenth"}
	 	if (daym == 19){daym = "nineteenth"}
	 	if (daym == 20){daym = "twentieth"}
	 	if (daym == 21){daym = "twenty first"}
	 	if (daym == 22){daym = "twenty second"}
	 	if (daym == 23){daym = "twenty third"}
	 	if (daym == 24){daym = "twenty fourth"}
	 	if (daym == 25){daym = "twenty fifth"}
	 	if (daym == 26){daym = "twenty sixth"}
	 	if (daym == 27){daym = "twenty seventh"}
	 	if (daym == 28){daym = "twenty eighth"}
	 	if (daym == 29){daym = "twenty ninth"}
	 	if (daym == 30){daym = "thirtieth"}
	 	if (daym == 31){daym = "thirty first"}
	 	
	 	//Day
	 	//TODO - Convert to array v1.1
	 	if (day == 1) {
	 		day = "Monday"
	 	}
	 	else if (day == 2) {
	 		day = "Tuesday"
	 	}
	 	else if (day == 3) {
	 		day = "Wednesday"
	 	}
	 	else if (day == 4) {
	 		day = "Thursday"
	 	}
	 	else if (day == 5) {
	 		day = "Friday"
	 	}
	 	else if (day == 6) {
	 		day = "Saturday"
	 	}
	 	else {
	 		day = "Sunday"
	 	}

	 	//Month
	 	//TODO - Convert to array v1.1
	 	if (month == 0){
	 		month = "January"
	 	}
	 	else if (month == 1){
	 		month = "Febuary"
	 	}
	 	else if (month == 2){
	 		month = "March"
	 	}
	 	else if (month == 3){
	 		month = "April"
	 	}
	 	else if (month == 4){
	 		month = "May"
	 	}
	 	else if (month == 5){
	 		month = "June"
	 	}
	 	else if (month == 6){
	 		month = "July"
	 	}
	 	else if (month == 7){
	 		month = "August"
	 	}
	 	else if (month == 8){
	 		month = "September"
	 	}
	 	else if (month == 9){
	 		month = "October"
	 	}
	 	else if (month == 10){
	 		month = "November"
	 	}
	 	else{
	 		month = "December"
	 	}
	 	
	 	//date = day+" "+daym+", "+month;
	 	date = 'the '+daym+' of '+month;

	 	//Display Output

	 	if (TwentyFourHour == true){   
	 		var time = h+':'+m;
	 	}
	 	if (TwentyFourHour == false){   
	 		var time = hTw+':'+m;
	 	}
	   
	    if (ampm == true){
		    var time = time+" "+tod
	    }
	   
	    $("p#time").text(time);
     	$("p#arrow").text("g");
     	$("p#day").text(day);
	    $("p#date").text(date);
	    $("div#overlap").css("color", DayColour);
	    
	    if (month == "January" && daym == "1"){		//Happy New Year
	 		$("p#secret").text("Happy New Year!");
	 	}
	    setTimeout(refreshData, x*1000);
	}
	  
	refreshData(); // execute function		//End Script