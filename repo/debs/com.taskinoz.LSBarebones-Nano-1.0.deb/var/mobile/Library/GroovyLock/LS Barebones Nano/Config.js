var TwentyFourHour = true; // 12 of 24 hour time
var ZeroAtMidnight = false;
var ampm = true;
var ClockHeight = 476;
var Language = "en"; // Only English [en], Portuguese [pg], German [ge], French [fr], Spanish [sp], Russian [ru], Finnish [fn], and Danish [dn]
