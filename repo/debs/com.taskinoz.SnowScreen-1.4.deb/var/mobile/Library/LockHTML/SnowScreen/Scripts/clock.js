//Clock by Taskinoz at Taskinoz.com

function refreshData()					//Start Script
	{
	    x = 1;  // x = seconds
	 	var d = new Date();
	 	var h = d.getHours(), hTw = d.getHours();
	 	var m = d.getMinutes();
	 	var s = d.getSeconds();
	 	var day = d.getDay();
	 	var month = d.getMonth();
		var daym = d.getDate();

		//12 Hour Time
		tod = ( hTw < 12 ) ? "am" : "pm";
		hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
		hTw = ( hTw == 0 ) ? 12 : hTw;
		
		if (h<=9) {h = '0'+h};
		if (m<=9) {m = '0'+m};
		if (s<=9) {s = '0'+s};
		
	 	//Day
	 	if (day == 1) {
	 		day = "Monday"
	 	}
	 	else if (day == 2) {
	 		day = "Tuesday"
	 	}
	 	else if (day == 3) {
	 		day = "Wednesday"
	 	}
	 	else if (day == 4) {
	 		day = "Thursday"
	 	}
	 	else if (day == 5) {
	 		day = "Friday"
	 	}
	 	else if (day == 6) {
	 		day = "Saturday"
	 	}
	 	else {
	 		day = "Sunday"
	 	}

	 	//Month
	 	if (month == 0){
	 		month = "January"
	 	}
	 	else if (month == 1){
	 		month = "Febuary"
	 	}
	 	else if (month == 2){
	 		month = "March"
	 	}
	 	else if (month == 3){
	 		month = "April"
	 	}
	 	else if (month == 4){
	 		month = "May"
	 	}
	 	else if (month == 5){
	 		month = "June"
	 	}
	 	else if (month == 6){
	 		month = "July"
	 	}
	 	else if (month == 7){
	 		month = "August"
	 	}
	 	else if (month == 8){
	 		month = "September"
	 	}
	 	else if (month == 9){
	 		month = "October"
	 	}
	 	else if (month == 10){
	 		month = "November"
	 	}
	 	else{
	 		month = "December"
	 	}
	 	
	 	date = day+" "+daym+", "+month;

	 	//Display Output

	 	if (TwentyFourHour == true){   
	 		var time = h+':'+m;
	 	}
	 	if (TwentyFourHour == false){   
	 		var time = hTw+':'+m+" "+tod;
	 	}
	    
	    if (ShowTime == true){
	    	$("p#time").text(time);
	    }
     	
     	if (ShowDate == true){
	    	$("p#date").text(date);
	    }
	    if (month == "January" && daym == "1"){
	 		$("p#secret").text("Happy New Year!");
	 	}
	    setTimeout(refreshData, x*1000);
	}
	  
	refreshData(); // execute function		//End Script