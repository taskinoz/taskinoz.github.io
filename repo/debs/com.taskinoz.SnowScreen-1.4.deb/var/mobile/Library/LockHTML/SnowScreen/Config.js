// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var ShowTime = true;						//Show Clock
var ShowDate = true;						//Show Date
var MaxParticles = 25;						//Set the amount of snow particles