//UPPERCASE: TASKINOZ
//lowercase: original developer

//DAYKLOK BY TASKINOZ - MODIFIED FROM DAYCLOKCK BY CTN

var Time24 = true;
/* dont change anything below this line unless you know what you are doing :-) */
//YOU CANT TELL ME WHAT TO DO...
//...WAIT WHATS HAPPENING, WHY IS EVERYTHING BREAKING

var d = new Date();
var hours = d.getHours();
var minutes = d.getMinutes();
var seconds = d.getSeconds();
var time, reacthours, reactmin, reactphase;


function initiate() {
	phasenum = phase();
	//$('#time, #shadow').html(Time());
	//$('#date, #date-shadow').html(cDate());
	
	$('#swap-two').css({'background-image' : 'url(Images/' + phasenum + '.png)', 'opacity' : 1}).doTimeout(2000, function() {
		$('#swap-one').css({'background-image' : 'url(Images/' + phasenum + '.png)'});
		$(this).css({'opacity' : 0});
		$('#time, #shadow, #date, #date-shadow').css({'opacity' : 1});
	});
	
	update(); // starts normal clock updating process
}

function update() {	
	//d = new Date();
	//hours = d.getHours();
	//minutes = d.getMinutes();
	//seconds = d.getSeconds();

	bg_change = react(); // check if background should be change (this is mainly to prevent unnecessary battery drain) important !
	
	//console.log(bg_change + ' ' + hours);		//debug

	if (bg_change) {
		phasenum = phase();
		
		$('#time, #shadow, #date, #date-shadow').css({'opacity' : 0}).doTimeout(1000, function() {
			$('#swap-two').css({'background-image' : 'url(Images/' + phasenum + '.png)', 'opacity' : 1}).doTimeout(2000, function() {
				$('#swap-one').css({'background-image' : 'url(Images/' + phasenum + '.png)'});
				$(this).css({'opacity' : 0});
				$('#time, #shadow, #date, #date-shadow').css({'opacity' : 1});
			});
		});		
	} else {
		$('#time, #shadow').html(Time());
		$('#date, #date-shadow').html(cDate());
	}
	
	setTimeout(update, 1000);
}	

//THESE TIMES ARE BASED ON US AVERAGES FOR SUNRISE AND SUNSET (IN WINTER I THINK)
//TO MODIFY THE TIME OF WALLPAPER CHANGE USE 24 HOUR TIME

function phase () {
	if (hours < 6.5) {     //I THINK SOMETHING DOWN HERE MIGHT BE BROKEN (LIKE THE FIRST WALLPAPER DOESNT SHOW UP) BUT IT SHOULD BE FINE
		//MORNING
		phasen = 1;
	} else if (hours < 7) {
		//SUNRISE
		phasen = 2;
	} else if (hours < 10) {
		//LATE MORNING
		phasen = 3;
	} else if (hours < 16) {
		//AFTERNOON
		phasen = 4;
	} else if (hours < 16.5) {
		//LATE AFTERNOON
		phasen = 5;
	} else if (hours < 17) {
		//SUNSET
		phasen = 6;
	} else if (hours < 17.5) {
		//EVENING
		phasen = 7;
	} else if (hours < 20) {
		//NIGHT
		phasen = 8;
	} else {
		//DARK, JUST REALLY DARK
		phasen = 9;
	}
	
	return phasen;
}


function react () {
	if (reacthours != undefined) {
		if (reactphase != phase()) {
			reacthours = hours;		// new value (changes every hour) :-)
			reactmin = minutes;		//new value (used for debug purposes mostly)
			reactphase = phase();	// new value
			
			return true; // background should be changed
		} else {
			return false;
		}	
	} else {
		//defines variable in the begining
		reacthours = hours;
		reactmin = minutes;
		reactphase = phase();
		
		return false;
	}
}


//THIS HAD A CLOCK AT SOME POINT BUT WITH THE MODIFICATION THIS PART ISNT NEEDED

/*function Time () {
	if (Time24) {
		if (hours < 10) hours = '0' + hours;
		if (minutes < 10) minutes = '0' + minutes;
		if (seconds < 10) seconds = '0' + seconds;
		
		return hours + ":" + minutes + ('<span>' + seconds + '</span>');
	} else {
		if (hours < 13) am = "am";
		else am = "pm";	
		if (hours > 12) hours -= 12;
		
		if (hours < 1)	hours = '12';
		if (hours < 10)	hours = '0' + hours;
		if (minutes < 10) minutes = "0" + minutes;
		
		return hours + ":" + minutes + ('<span>' + am + '</span>');
	}
}


function cDate () {
	var month = d.getMonth() + 1;
	if (month < 10) month = '0' + month; 
	
	if (d.getDate() < 10) {
		var daynum = "0" + d.getDate();
	} else {
		var daynum = d.getDate();
	}

	return Day() + ' ' + daynum + '.' + month;
}


function Day () {
    day = new Array("SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY");
    return day[d.getDay()];
}
*/
