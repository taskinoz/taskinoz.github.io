//Clock by Taskinoz at Taskinoz.com

function refreshData(){
	var d = new Date();
	var h = d.getHours(), hTw = d.getHours();
	var m = d.getMinutes();
	var s = d.getSeconds();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();
	
	//12 Hour Time
	tod = ( hTw < 12 ) ? "AM" : "PM";
	hTw = ( hTw > 12 ) ? hTw - 12 : hTw;
	hTw = ( hTw == 0 ) ? 12 : hTw;
	
	//2 Digit Time and Date	
	if (h<=9) {h = '0'+h};
	if (hTw<=9) {hTw = '0'+hTw};
	if (m<=9) {m = '0'+m};
	if (s<=9) {s = '0'+s};
	if (daym<=9) {daym = '0'+daym}
	
	//Midnight Fix
	if (tod == "AM" && hTw >= 12){hTw = "00"};
	
	//Weekday and Month arrays
	weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	months = ["January","Febuary","March","April","May","June","July","August","September","October","November","December"]
	day = weekday[day];
	month = months[month];
	
	if (ShowMonth == true){month = ", "+month}
	else(month = "")
	date = day+" "+daym+month;

	//Display Output
	if (TwentyFourHour == true){   
		var time = h+':'+m;
	}
	if (TwentyFourHour == false){   
		var time = hTw+':'+m;
	}
	$("p#time").text(time);
	$("p#date").text(date);
	
	//CSS Colours
	$("p").css("color",FontColor);
	if (ShowBattery == true){
		$("#bar").css("background-color",BarColor);
		$("#bar2").css("background-color",PercentageColor);
	}
	
	//Bar Position
	if (InvertDisplay == true){
		$("p").css("top","0px");
		if (ShowBattery == true){
			$("#bar").css("top","-16px");
			$("#bar2").css("top","-16px");
		}
	}
}
setInterval(refreshData, 1000); //Fix by /u/SOMECoder
	  
refreshData(); // execute function		//End Script