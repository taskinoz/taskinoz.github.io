//Clock by Taskinoz at Taskinoz.com

function refreshData(){
	//Set the variables for Day, Hours, Minutes, Seconds
	//--------------------------------------------------------
	var d = new Date();
	var h = d.getHours(), h12 = d.getHours();
	var m = d.getMinutes();
	var s = d.getSeconds();
	var day = d.getDay();
	var month = d.getMonth();
	var daym = d.getDate();
	var year = d.getYear() + 1900;
	//--------------------------------------------------------
	//12 Hour Time
	//--------------------------------------------------------
	tod = ( h12 < 12 ) ? "AM" : "PM";
	h12 = ( h12 > 12 ) ? h12 - 12 : h12;
	h12 = ( h12 == 0 ) ? 12 : h12;

	if (h<=9) {h = '0'+h};
	if (h12<=9) {h12 = '0'+h12};
	//if (h12<=9) {h12 = '0'+h12};
	if (m<=9) {m = '0'+m};
	if (s<=9) {s = '0'+s};
	//if (daym<=9) {daym = '0'+daym}
	//--------------------------------------------------------
	//Formatting Variables
	//--------------------------------------------------------
	//var date = dayA[day]+", "+monthA[month]+" "+daym;
	if (ampm == false){tod = "";}
	if (TwentyFourHour == true){var time = h+':'+m;}
	if (TwentyFourHour == false){var time = h12+':'+m+" "+tod;}
	//--------------------------------------------------------
	//jQuery Output
	$("#time-top").text(time);
	$("#time-bottom").text(time);
	//--------------------------------------------------------
	}


function init() {
	// Listen for the deviceorientation event and handle the raw data
	window.addEventListener('deviceorientation', function(eventData) {
	// gamma is the left-to-right tilt in degrees, where right is positive
	var tiltLR = eventData.gamma;

	// beta is the front-to-back tilt in degrees, where front is positive
	var tiltFB = eventData.beta;

	// alpha is the compass direction the device is facing in degrees (not used)
	var dir = eventData.alpha

	// call our orientation event handler
	deviceOrientationHandler(tiltLR, tiltFB, dir);
	}, false);
}
function deviceOrientationHandler(tiltLR, tiltFB, dir) {
			var windowwidth = $( window ).width();
			var windowheight = $( window ).height();
			//time-top
			$("#time-top").css("top",(windowheight/2)+tiltFB);
			$("#time-top").css("left",(windowwidth/4)+tiltLR);
			//Time-bottom
			$("#time-bottom").css("top",(windowheight/2)-tiltFB);
			$("#time-bottom").css("left",(windowwidth/4)-tiltLR);
    }
setInterval(refreshData, 1000);
init();
refreshData();
