// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var ClockHeight = 50;
var compact = true;
var color = "000000";
var Language = "en"; 						//Only English [en] Portuguese [pg] French [fr] Spanish [sp] German [ge]
