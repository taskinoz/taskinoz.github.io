// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var ampm = false;
var unit = "c";
var woeid = 1105779;
var ClockHeight = 50;