//Taken from Cataracs and modified by Taskinoz
//Battery
function refreshData(){					//Start Script	
	$.get("file:///var/mobile/Library/Stats/BatteryStats.txt", function(data){
		var split = data.split("\n");
		var level = split[0].split(": ")[1];
		var state = split[1].split(": ")[1];
		$("h1#battery").text(level+'%');
		$("h2#state").text(state);
	});
	setTimeout(refreshData, x*1000);
	}
refreshData();