// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var ampm = false;
var unit = "c";
var woeid = 1105779;
var BackgroundColour = "#e18094";
var ShowBackground = false;
var ShowList = false;
var TopText = "Line 1";
var BottomText = "Line 2";