// Configuration Clock //

var TwentyFourHour = false;					//12 of 24 hour time
var Roundness = 0;